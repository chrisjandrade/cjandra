#!/bin/sh
npm run build && npm start