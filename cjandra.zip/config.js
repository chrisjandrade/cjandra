
module.exports = {
	DEV_SERVER_PORT: 3000,
	PROD_SERVER_PORT: 80
};
