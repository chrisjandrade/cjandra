
module.exports = {
	DEV_SERVER_PORT: 8080,
	PROD_SERVER_PORT: 80
};
